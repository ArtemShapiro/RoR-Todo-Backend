var ROW_COUNT = 5;
var COL_COUNT = 5;
var X_SAMPLE = [1, 0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 1]
var Y_SAMPLE = [1, 0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0]
var Z_SAMPLE = [1, 1, 1, 1, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 1, 1, 1, 1]
var NOISE_STRENGTH = 0.1; //0 - no noise, 0.5 - full noise, 1 - invert

function h1(text) {
  var x = document.createElement('h1');
  var t = document.createTextNode(text);
  x.appendChild(t);
  document.body.appendChild(x);
}

function table(tableArray) {
  var index = 0;
  var table = document.createElement('table');
    for(var i = 0; i < COL_COUNT; i++) {
      var tr = document.createElement('tr');
      for(var j = 0; j < ROW_COUNT; j++) {
        var td = document.createElement('td');
        if(tableArray[index]) td.className = 'black';
        index++;
        tr.appendChild(td);
      }
      table.appendChild(tr);
    }
  document.body.appendChild(table);
}

//SHOW SAMPLES
//h1('X SAMPLE:');
table(X_SAMPLE);
//h1('Y SAMPLE:');
table(Y_SAMPLE);
//h1('Z SAMPLE:');
table(Z_SAMPLE);
document.body.appendChild(document.createElement('br'));

function noisyInputs(letter) {
  var hint = document.createTextNode('Number of noisy ' + letter + ': ');
  document.body.appendChild(hint);
  var input = document.createElement('input');
  input.value = '10';
  input.id = letter;
  document.body.appendChild(input);
  document.body.appendChild(document.createElement('br'));
}

//LET USER CHOOSE NUMBER OF NOISY DUPLICATES
noisyInputs('X');
noisyInputs('Y');
noisyInputs('Z');

document.body.appendChild(document.createElement('br'));
var buttonNoiseIt = document.createElement('button');
buttonNoiseIt.appendChild(document.createTextNode('Get training sample'));
document.body.appendChild(buttonNoiseIt);

var buttonGetExamFile = document.createElement('button');
buttonGetExamFile.appendChild(document.createTextNode('Get exam sample'));
document.body.appendChild(buttonGetExamFile);

document.body.appendChild(document.createElement('br'));
buttonNoiseIt.addEventListener('click', function() { saveNoisy(true) });
buttonGetExamFile.addEventListener('click', function() { saveNoisy(false) });

function saveNoisy(display) {
  var x_num = parseInt(document.getElementById('X').value);
  var y_num = parseInt(document.getElementById('Y').value);
  var z_num = parseInt(document.getElementById('Z').value);
  
  var n = x_num + y_num + z_num;
  var x_prob = x_num / n;
  var y_prob = y_num / n;
  var z_prob = z_num / n;

  var str_to_save = '';

  for(var i = 0; i < n; i++) {
    var r = Math.random();
    if(r < x_prob && x_num) {
      noise(X_SAMPLE, 'X');
      x_num--;
    } else if(r < (x_prob + y_prob) && y_num) {
      noise(Y_SAMPLE, 'Y');
      y_num--;
    } else if(z_num) {
      noise(Z_SAMPLE, 'Z');
      z_num--;
    } else if(x_num) {
      noise(X_SAMPLE, 'X');
      x_num--;
    } else if(y_num) {
      noise(Y_SAMPLE, 'Y');
      y_num--;
    }
  }

  function noise(sample, letter) {
    var noisy_array = [];
    for(var i = 0; i < sample.length; i++) {
      if(Math.random() < NOISE_STRENGTH) {
        if(sample[i]) noisy_array.push(0);
        else noisy_array.push(1);
      } else noisy_array.push(sample[i]);
      str_to_save = str_to_save.concat(noisy_array[i]);
      str_to_save = str_to_save.concat(' ');
    }
  if(display) str_to_save = str_to_save.concat(letter + '\n');
  else str_to_save = str_to_save.concat('\n');
  if(display) table(noisy_array);
  }

  var blob = new Blob([str_to_save], {type: "text/plain;charset=utf-8"});
  if(display) saveAs(blob, "training_sample.txt");
  else saveAs(blob, "exam_sample.txt");
}
